﻿using InventoryDataAccess.Models;
using InventoryServices.Models;

namespace InventoryServices.Infrastructure
{
    public class AutomapperProfile : AutoMapper.Profile
    {
        public AutomapperProfile()
        {
            CreateMap<InventoryModel, InventoryValues>();
            CreateMap<InventoryValues, InventoryModel>();
        }
    }
}
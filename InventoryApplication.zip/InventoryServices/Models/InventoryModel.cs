﻿namespace InventoryServices.Models
{
    /// <summary>
    /// Model for Creating the Inventory
    /// </summary>
    public class InventoryModel
    {
        /// <summary>
        /// Item Id for the item
        /// </summary>
        public string ItemId { get; set; }

        /// <summary>
        /// Description for Item
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Per unit cost of Item
        /// </summary>
        public decimal UnitCost { get; set; }

        /// <summary>
        /// The type of item
        /// </summary>
        public string ItemType { get; set; }
    }
}

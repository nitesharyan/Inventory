﻿using AutoMapper;
using InventoryBusiness.Inventory;
using InventoryDataAccess.Models;
using InventoryServices.Exceptions;
using InventoryServices.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace InventoryServices.Controllers
{
    /// <summary>
    /// API controller only allowing access to admin
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    [Authorize(Roles = "Admin")]
    // Need to define this Admin Class as per requirement and userId
    public class InventoryController : ControllerBase
    {
        private readonly ILogger<InventoryController> _logger;
        private readonly IMapper _mapper;
        public InventoryController(ILogger<InventoryController> logger, IMapper mapper)
        {
            _logger = logger;
            _mapper = mapper;
        }

        /// <summary>
        /// Insert record to Inventory table
        /// </summary>
        /// <param name="inventory">Inventory data</param>
        /// <returns>Succes/failure of API</returns>
        public ActionResult InsertItem(InventoryModel inventory)
        {
            try
            {
                if (inventory == null)
                {
                    throw new ServiceException("No data to insert in inventory");
                }
                if (inventory.ItemId == null || inventory.Description == null)
                {
                    throw new ServiceException("Improper data provided");
                }
                InventoryBusinessController inventoryBusinessController = new();

                var inventoryData = _mapper.Map<InventoryValues>(inventory);

                if (!inventoryBusinessController.InsertNewItem(inventoryData))
                {
                    throw new ServiceException($"Unable to insert the Item with ID : {inventory.ItemId}");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid data provided " + ex.Message);
            }
            return Ok(inventory);
        }

        /// <summary>
        /// Delete API for deleting an item from inventory
        /// </summary>
        /// <param name="itemId">Id of the item</param>
        /// <returns>Success/Failure of API</returns>
        public ActionResult DeleteItem(string itemId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(itemId))
                {
                    throw new ServiceException("Invalid data provided");
                }
                InventoryBusinessController inventoryBusinessController = new();

                if (!inventoryBusinessController.RemoveItem(itemId))
                {
                    throw new ServiceException($"Unable to insert the Item with ID : {itemId}");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid data provided " + ex.Message);
            }
            return Ok(itemId);
        }

        /// <summary>
        /// Update a record in Inventory table
        /// </summary>
        /// <param name="item">Item data</param>
        /// <returns>Success/Failure of API</returns>
        public ActionResult UpdateItem(InventoryModel item)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(item.ItemId))
                {
                    throw new ServiceException("Invalid data provided");
                }
                InventoryBusinessController inventoryBusinessController = new();

                var inventoryData = _mapper.Map<InventoryValues>(item);

                if (!inventoryBusinessController.UpdateItem(inventoryData))
                {
                    throw new ServiceException($"Unable to insert the Item with ID : {item.ItemId}");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid data provided " + ex.Message);
            }
            return Ok(item);
        }

        /// <summary>
        /// API to get an Item from inventory table
        /// </summary>
        /// <param name="itemId">id to Get</param>
        /// <returns>Item data</returns>
        public InventoryModel GetItem(string itemId)
        {
            InventoryModel item;
            try
            {
                if (string.IsNullOrWhiteSpace(itemId))
                {
                    throw new ServiceException("Invalid data provided");
                }
                InventoryBusinessController inventoryBusinessController = new();

                item = _mapper.Map<InventoryModel>(inventoryBusinessController.GetItem(itemId));
            }
            catch (Exception)
            {
                return null;
            }
            return item;
        }

        /// <summary>
        /// API to get list of all items in database
        /// </summary>
        /// <returns>List of items</returns>
        public List<InventoryModel> GetAllItems()
        {
            List<InventoryModel> items;
            try
            {
                InventoryBusinessController inventoryBusinessController = new();

                items = _mapper.Map<List<InventoryModel>>(inventoryBusinessController.GetAllItems());
            }
            catch (Exception)
            {
                return null;
            }
            return items;
        }
    }
}

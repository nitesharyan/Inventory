﻿using InventoryDataAccess.Exceptions;
using InventoryDataAccess.Models;
using System.Collections.Generic;

namespace InventoryBusiness.Inventory
{
    /// <summary>
    /// Business layer Controller for Inventory
    /// </summary>
    public class InventoryBusinessController
    {
        /// <summary>
        /// Insert record to Inventory table
        /// </summary>
        /// <param name="inventory">Inventory data</param>
        /// <returns>Boolean value if record was inserted</returns>
        public bool InsertNewItem(InventoryValues inventory)
        {
            InventoryDataController inventoryDataController = new();
            return inventoryDataController.AddItem(inventory);
        }

        /// <summary>
        /// Method for deleting an item from inventory
        /// </summary>
        /// <param name="itemId">Id of the item</param>
        /// <returns>Boolean value if record was deleted</returns>
        public bool RemoveItem(string itemId)
        {
            InventoryDataController inventoryDataController = new();
            return inventoryDataController.RemoveItem(itemId);
        }

        /// <summary>
        /// Method for updating an item from inventory
        /// </summary>
        /// <param name="item">Item data to be updated</param>
        /// <returns>Boolean value if record was deleted</returns>
        public bool UpdateItem(InventoryValues item)
        {
            InventoryDataController inventoryDataController = new();
            return inventoryDataController.UpdateItem(item);
        }

        /// <summary>
        /// Gets an item based on item id passed
        /// </summary>
        /// <param name="itemId">Id of the item</param>
        /// <returns>Inventory data</returns>
        public InventoryValues GetItem(string itemId)
        {
            InventoryDataController inventoryDataController = new();
            return inventoryDataController.GetItem(itemId);
        }

        /// <summary>
        /// Gets list of all items
        /// </summary>
        /// <returns>IEnumerable data of items</returns>
        public IEnumerable<InventoryValues> GetAllItems()
        {
            InventoryDataController inventoryDataController = new();
            return inventoryDataController.GetAllItems();
        }
    }
}

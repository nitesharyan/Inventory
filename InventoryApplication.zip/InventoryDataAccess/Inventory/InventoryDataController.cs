﻿using InventoryDataAccess.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace InventoryDataAccess.Exceptions
{
    /// <summary>
    /// Data access layer Controller for Inventory
    /// </summary>
    public class InventoryDataController
    {
        /// <summary>
        /// DbContext object
        /// </summary>
        private ApplicationDbContext db = new ApplicationDbContext();

        /// <summary>
        /// Insert record to Inventory table
        /// </summary>
        /// <param name="item">Inventory data</param>
        /// <returns>Boolean value if record was inserted</returns>
        public bool AddItem(InventoryValues item)
        {
            try
            {
                item.CreatedAt = DateTime.Now;
                if (CheckIfItemExists(item.ItemId))
                {
                    throw new ItemAlreadyExistsException("Item already exists");
                }
                else
                {
                    item.CreatedAt = DateTime.Now;
                    db.InventoryValues.Add(item);
                    db.Entry(item).State = EntityState.Added;
                    db.SaveChanges();
                    return true;
                }
            }
            catch (ItemAlreadyExistsException)
            {
                throw;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Gets an item based on item id passed
        /// </summary>
        /// <param name="itemId">Id of the item</param>
        /// <returns>Inventory data</returns>
        public InventoryValues GetItem(string itemId)
        {
            try
            {
                if (!CheckIfItemExists(itemId))
                {
                    throw new ItemNotExistsException("Item doesn't exists");
                }
                else
                {
                    var item = db.InventoryValues.FirstOrDefault(x => x.ItemId.Equals(itemId));
                    return item;
                }
            }
            catch (ItemNotExistsException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Gets list of all items
        /// </summary>
        /// <returns>IEnumerable data of items</returns>
        public IEnumerable<InventoryValues> GetAllItems()
        {
            return db.InventoryValues.Where(x => !x.IsDeleted).AsEnumerable();
        }

        /// <summary>
        /// Method for deleting an item from inventory
        /// </summary>
        /// <param name="itemId">Id of the item</param>
        /// <returns>Boolean value if record was deleted</returns>
        public bool RemoveItem(string itemId)
        {
            try
            {
                if (!CheckIfItemExists(itemId))
                {
                    throw new ItemNotExistsException("Item doesn't exists");
                }
                else
                {
                    var item = db.InventoryValues.FirstOrDefault(x => x.ItemId.Equals(itemId));
                    item.DeletedAt = DateTime.Now;
                    item.IsDeleted = true;
                    db.InventoryValues.Attach(item);
                    db.Entry(item).State = EntityState.Modified;
                    db.SaveChanges();
                    return true;
                }
            }
            catch (ItemAlreadyExistsException)
            {
                throw;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Method for updating an item from inventory
        /// </summary>
        /// <param name="item">Item data to be updated</param>
        /// <returns>Boolean value if record was deleted</returns>
        public bool UpdateItem(InventoryValues item)
        {
            try
            {
                if (!CheckIfItemExists(item.ItemId))
                {
                    throw new ItemNotExistsException("Item doesn't exists");
                }
                else
                {
                    db.InventoryValues.Attach(item);
                    db.Entry(item).State = EntityState.Modified;
                    db.SaveChanges();
                    return true;
                }
            }
            catch (ItemNotExistsException)
            {
                throw;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Method to check Item exists or not
        /// </summary>
        /// <param name="itemId">Item Id to be checked</param>
        /// <returns>Boolean value if item exists</returns>
        private bool CheckIfItemExists(string itemId)
        {
            bool itemExists = db.InventoryValues.Any(x => x.ItemId.Equals(itemId) && !x.IsDeleted);
            return itemExists;
        }
    }
}

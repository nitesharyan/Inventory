﻿using System;
using System.Runtime.Serialization;

namespace InventoryDataAccess.Exceptions
{
    [Serializable]
    internal class ItemNotExistsException : Exception
    {
        public ItemNotExistsException()
        {
        }

        public ItemNotExistsException(string message) : base(message)
        {
        }

        public ItemNotExistsException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ItemNotExistsException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
﻿using InventoryDataAccess.Models;
using System.Data.Entity;

namespace InventoryDataAccess
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<InventoryValues> InventoryValues { get; set; }
        public ApplicationDbContext()
            : base("InventoryServicesCS")
        {
        }

    }
}

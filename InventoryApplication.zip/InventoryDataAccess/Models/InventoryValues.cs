﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InventoryDataAccess.Models
{
    /// <summary>
    /// Model for Creating the Inventory table
    /// </summary>
    public class InventoryValues
    {
        /// <summary>
        /// Primary and indentity key column
        /// </summary>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Item Id for the item
        /// </summary>
        [Required]
        [StringLength(40)]
        [DataType("NVARCHAR")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Special character should not be entered")]
        public string ItemId { get; set; }

        /// <summary>
        /// Description for Item
        /// </summary>
        [Required]
        public string Description { get; set; }

        /// <summary>
        /// Per unit cost of Item
        /// </summary>
        public decimal UnitCost { get; set; }

        /// <summary>
        /// The type of item
        /// </summary>
        public string ItemType { get; set; }

        /// <summary>
        /// Whether the item is deleted or not
        /// </summary>
        [Required]
        [DefaultValue(false)]
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Item created at
        /// </summary>
        [Required]
        [DataType(DataType.Date)]
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// Item deleted at
        /// </summary>
        [DataType(DataType.Date)]
        public DateTime? DeletedAt { get; set; }

        /// <summary>
        /// Item modified at
        /// </summary>
        [DataType(DataType.Date)]
        public static DateTime? ModifiedAt => DateTime.Now;
    }
}
